# sorting

# numbers = [3, 1, 7, 89, 2, 6, 5]
# print(sorted(numbers))
# sorted_num = sorted(numbers)
#
# print(hex(id(numbers)))
# print(hex(id(sorted_num)))
# print(sorted_num)
# #print(sorted(numbers, reverse=True))
# sorted_list = numbers.sort()
# print(hex(id(numbers)))
# print(sorted_list)
# print(numbers)

# students = [("Sameer", 32), ("Shalu", 21), ("Raman", 46), ("Ram", 23), ("Anne", 21)]
#
# from operator import itemgetter
#
# print(sorted(students, key=itemgetter(0)))
# print(sorted(students, key=itemgetter(1, 0)))

# OS Module

# import os
#
# print(os.getcwd())
# os.chdir('../')
# print(os.getcwd())
# #os.makedirs('abc/def/ghi')
# print(os.path.join(os.getcwd(),'users', 'projects', 'test.txt'))

# Subprocess

import subprocess
subprocess.Popen("notepad.exe")

