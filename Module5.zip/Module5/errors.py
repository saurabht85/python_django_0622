#semantec error

def sorting(l):
    return l.sort()


nums = [10, 9, 3, 13, 7 , 16]
print(sorting(nums))
