# import keyword
#
# print(keyword.kwlist)

# Arguments

#name = "Saurabh"

import sys


#name = input("What is your name: ")
# if len(sys.argv) != 3:
#     print("Script needs atleast two arguments. Name and age")
#     sys.exit(1)
# name = sys.argv[1]
# age = sys.argv[2]
# print(f"hello {name}. You are {age} years old")


# Input

num1 = int(input("Enter a number: "))
num2 = int(input("Enter another number: "))

print(f"{num1} * {num2} = {num1*num2}")
